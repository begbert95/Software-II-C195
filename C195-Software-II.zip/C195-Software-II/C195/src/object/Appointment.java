package object;

import helper.JDBC;

import java.sql.*;
import java.time.*;

public class Appointment {
    private int appointmentID;
    private String title;
    private String description;
    private String location;
    private String type;
    private Instant start;
    private Instant end;
    private Instant createDate;
    private String createdBy;
    private Instant updateDate;
    private String updatedBy;
    private int customerID;
    private int userID;
    private int contactID;
    private String contactName;

    /**
     *
     * @param appointmentID appointment ID
     * @param title title of appointment
     * @param description description of appointment
     * @param location location of appointment
     * @param type type of appointment
     * @param start start of appointment
     * @param end end of appointment
     * @param createDate creation date of appointment
     * @param createdBy creator of appointment
     * @param updateDate update date of appointment
     * @param updatedBy updater of of appointment
     * @param customerID customer id of appointment
     * @param userID user id of appointment
     * @param contactID contact id of appointment
     * @param contactName name of contact of appointment
     */
    public Appointment(
           int appointmentID,
           String title,
           String description,
           String location,
           String type,
           Instant start,
           Instant end,
           Instant createDate,
           String createdBy,
           Instant updateDate,
           String updatedBy,
           int customerID,
           int userID,
           int contactID,
           String contactName
    ) {
        this.appointmentID = appointmentID;
        this.title = title;
        this.description = description;
        this.location = location;
        this.type = type;
        this.start = start;
        this.end = end;
        this.createDate = createDate;
        this.createdBy = createdBy;
        this.updateDate = updateDate;
        this.updatedBy = updatedBy;
        this.customerID = customerID;
        this.userID = userID;
        this.contactID = contactID;
        this.contactName = contactName;
    }

    /**
     *
     * @param rs takes result set to create appointment
     */
    public Appointment(ResultSet rs){
        try{
            this.appointmentID = rs.getInt("Appointment_ID");
            this.title = rs.getString("Title");
            this.description = rs.getString("Description");
            this.location = rs.getString("Location");
            this.type = rs.getString("Type");
            this.start = rs.getTimestamp("Start").toInstant();
            this.end = rs.getTimestamp("End").toInstant();
            this.createDate = rs.getTimestamp("Create_Date").toInstant();
            this.createdBy = rs.getString("Created_By");
            this.updateDate = rs.getTimestamp("Last_Update").toInstant();
            this.updatedBy = rs.getString("Last_Updated_By");
            this.customerID = rs.getInt("Customer_ID");
            this.userID = rs.getInt("User_ID");
            this.contactID = rs.getInt("Contact_ID");
        }
        catch (SQLException e){
            e.printStackTrace();
        }
    }

    /**
     * default constructor
     */
    public Appointment(){}

    /**
     *
     * @return appointmentID
     */
    public int getAppointmentID() {
        return appointmentID;
    }

    /**
     *
     * @param appointmentID appointmentid to set
     */
    public void setAppointmentID(int appointmentID) {
        this.appointmentID = appointmentID;
    }

    /**
     *
     * @return title
     */
    public String getTitle() {
        return title;
    }

    /**
     *
     * @param title title to set
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     *
     * @return description
     */
    public String getDescription() {
        return description;
    }

    /**
     *
     * @param description description to set
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     *
     * @return location
     */
    public String getLocation() {
        return location;
    }

    /**
     *
     * @param location to set
     */
    public void setLocation(String location) {
        this.location = location;
    }

    /**
     *
     * @return type
     */
    public String getType() {
        return type;
    }

    /**
     *
     * @param type to set
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     *
     * @return start
     */
    public Instant getStart() {
        return start;
    }

    /**
     *
     * @param start to set
     */
    public void setStart(Instant start) {
        this.start = start;
    }

    /**
     *
     * @return end
     */
    public Instant getEnd() {
        return end;
    }

    /**
     *
     * @param end to set
     */
    public void setEnd(Instant end) {
        this.end = end;
    }

    /**
     *
     * @return create date
     */
    public Instant getCreateDate() {
        return createDate;
    }

    /**
     *
     * @param createDate to set
     */
    public void setCreateDate(Instant createDate) {
        this.createDate = createDate;
    }

    /**
     *
     * @return createdBy
     */
    public String getCreatedBy() {
        return createdBy;
    }

    /**
     *
     * @param createdBy to set
     */
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    /**
     *
     * @return update date
     */
    public Instant getUpdateDate() {
        return updateDate;
    }

    /**
     *
     * @param updateDate to set
     */
    public void setUpdateDate(Instant updateDate) {
        this.updateDate = updateDate;
    }

    /**
     *
     * @return updatedby
     */
    public String getUpdatedBy() {
        return updatedBy;
    }

    /**
     *
     * @param updatedBy to set
     */
    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    /**
     *
     * @return customerID
     */
    public int getCustomerID() {
        return customerID;
    }

    /**
     *
     * @param customerID to set
     */
    public void setCustomerID(int customerID) {
        this.customerID = customerID;
    }

    /**
     *
     * @return user id
     */
    public int getUserID() {
        return userID;
    }

    /**
     *
     * @param userID to set
     */
    public void setUserID(int userID) {
        this.userID = userID;
    }

    /**
     *
     * @return contact ID
     */
    public int getContactID() {
        return contactID;
    }

    /**
     *
     * @param contactID to set
     */
    public void setContactID(int contactID) {
        this.contactID = contactID;
    }

    /**
     *
     * @param contactName to set
     */
    public void setContactName(String contactName){
        this.contactName = contactName;
    }

    /**
     *
     * @return contact name
     */
    public String getContactName(){
        return contactName;
    }

    /**
     *
     * @return start time converted to local time
     */
    public LocalDateTime getLocalStartDate(){
        return ZonedDateTime.ofInstant(start, ZoneId.systemDefault()).toLocalDateTime();
    }

    /**
     *
     * @return end time converted to local time
     */
    public LocalDateTime getLocalEndDate(){
        return ZonedDateTime.ofInstant(end, ZoneId.systemDefault()).toLocalDateTime();
    }

    /**
     *
     * @return boolean based on SQL return
     */
    public boolean deleteFromDatabase(){
        try {
            Connection conn = JDBC.getConnection();
            JDBC.makePreparedStatement("DELETE FROM APPOINTMENTS WHERE Appointment_ID = ?", conn);
            PreparedStatement preparedStatement = JDBC.getPreparedStatement();
            preparedStatement.setInt(1, appointmentID);
            return preparedStatement.executeUpdate() == 1;
        }
        catch (SQLException e){
            return false;
        }
    }

    /**
     *
     * @return boolean that checks for any unset values
     */
    public boolean validate(){
        if(appointmentID == 0)
            return false;
        if(title.isEmpty())
            return false;
        if(description.isEmpty())
            return false;
        if(location.isEmpty())
            return false;
        if(type.isEmpty())
            return false;
        if(start == null)
            return false;
        if(end == null)
            return false;
        if(createDate == null)
            return false;
        if(createdBy.isEmpty())
            return false;
        if(updateDate == null)
            return false;
        if(updatedBy.isEmpty())
            return false;
        if(customerID == 0)
            return false;
        if(userID == 0)
            return false;
        if(contactID == 0)
            return false;

        return true;
    }

    /**
     *
     * @return boolean of SQL results.
     */
    public boolean writeToDatabase(){
        try{
            Connection conn = JDBC.getConnection();
            JDBC.makePreparedStatement("SELECT Appointment_ID FROM Appointments WHERE Appointment_ID = ?", conn);

            PreparedStatement queryPreparedStatement = JDBC.getPreparedStatement();
            queryPreparedStatement.setInt(1, appointmentID);
            ResultSet resultSet = queryPreparedStatement.executeQuery();

            if(resultSet.next()){
                String query =
                        "UPDATE APPOINTMENTS SET Title = ?, " +
                                "Description = ?, " +
                                "Location = ?, " +
                                "Type = ?, " +
                                "Start = ?, " +
                                "End = ?, " +
                                "Last_Update = ?, " +
                                "Last_Updated_By = ?, " +
                                "Customer_ID = ?, " +
                                "User_ID = ?, " +
                                "Contact_ID = ? " +
                                "WHERE Appointment_ID = ?";
                System.out.println(query);
                JDBC.makePreparedStatement(query, conn);
                PreparedStatement updatePreparedStatement = JDBC.getPreparedStatement();
                updatePreparedStatement.setString(1, title);
                updatePreparedStatement.setString(2, description);
                updatePreparedStatement.setString(3, location);
                updatePreparedStatement.setString(4, type);
                updatePreparedStatement.setTimestamp(5, Timestamp.from(start));
                updatePreparedStatement.setTimestamp(6, Timestamp.from(end));
                updatePreparedStatement.setTimestamp(7, Timestamp.from(updateDate));
                updatePreparedStatement.setString(8, updatedBy);
                updatePreparedStatement.setInt(9, customerID);
                updatePreparedStatement.setInt(10, userID);
                updatePreparedStatement.setInt(11, contactID);
                updatePreparedStatement.setInt(12, appointmentID);

                return updatePreparedStatement.executeUpdate() == 1;
            }
            else{
                String query = "INSERT INTO APPOINTMENTS VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                JDBC.makePreparedStatement(query, conn);
                PreparedStatement updatePreparedStatement = JDBC.getPreparedStatement();
                updatePreparedStatement.setInt(1, appointmentID);
                updatePreparedStatement.setString(2, title);
                updatePreparedStatement.setString(3, description);
                updatePreparedStatement.setString(4, location);
                updatePreparedStatement.setString(5, type);
                updatePreparedStatement.setTimestamp(6, Timestamp.from(start));
                updatePreparedStatement.setTimestamp(7, Timestamp.from(end));
                updatePreparedStatement.setTimestamp(8, Timestamp.from(createDate));
                updatePreparedStatement.setString(9, createdBy);
                updatePreparedStatement.setTimestamp(10, Timestamp.from(updateDate));
                updatePreparedStatement.setString(11, updatedBy);
                updatePreparedStatement.setInt(12, customerID);
                updatePreparedStatement.setInt(13, userID);
                updatePreparedStatement.setInt(14, contactID);

                return updatePreparedStatement.executeUpdate() == 1;
            }
        }
        catch (SQLException e){
            e.printStackTrace();
            return false;
        }
    }
}
