package object;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;

public class Division {
    private int divID;
    private String name;
    private LocalDateTime createDate;
    private String createdBy;
    private LocalDateTime lastUpdate;
    private String updatedBy;
    private int countryID;
    private String countryName;

    /**
     *
     * @param divID division id
     * @param name division name
     * @param createDate division create date
     * @param createdBy division created by
     * @param lastUpdate division last updated
     * @param updatedBy division updated by
     */
    public Division(int divID, String name, LocalDateTime createDate, String createdBy, LocalDateTime lastUpdate, String updatedBy) {
        this.divID = divID;
        this.name = name;
        this.createDate = createDate;
        this.createdBy = createdBy;
        this.lastUpdate = lastUpdate;
        this.updatedBy = updatedBy;
    }

    /**
     *
     * @param rs result set to construct a division
     */
    public Division(ResultSet rs){
        try{
            this.divID = rs.getInt("Division_ID");
            this.name = rs.getString("Division");
            this.createDate = rs.getObject("Create_Date", LocalDateTime.class);
            this.createdBy = rs.getString("Created_By");
            this.lastUpdate = rs.getObject("Last_Update", LocalDateTime.class);
            this.updatedBy = rs.getString("Last_Updated_By");
            this.countryID = rs.getInt("Country_ID");
            this.countryName = CountryList.lookupCountry(countryID).getName();
        }
        catch (SQLException e){
            e.printStackTrace();
        }
    }

    /**
     *
     * @return division ID
     */
    public int getDivID() {
        return divID;
    }

    /**
     *
     * @param divID to set
     */
    public void setDivID(int divID) {
        this.divID = divID;
    }

    /**
     *
     * @return division name
     */
    public String getName() {
        return name;
    }

    /**
     *
     * @param name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     *
     * @return created date
     */
    public LocalDateTime getCreateDate() {
        return createDate;
    }

    /**
     *
     * @param createDate to set
     */
    public void setCreateDate(LocalDateTime createDate) {
        this.createDate = createDate;
    }

    /**
     *
     * @return created by
     */
    public String getCreatedBy() {
        return createdBy;
    }

    /**
     *
     * @param createdBy to set
     */
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    /**
     *
     * @return last update date
     */
    public LocalDateTime getLastUpdate() {
        return lastUpdate;
    }

    /**
     *
     * @param lastUpdate date to set
     */
    public void setLastUpdate(LocalDateTime lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    /**
     *
     * @return updated by
     */
    public String getUpdatedBy() {
        return updatedBy;
    }

    /**
     *
     * @param updatedBy user to set
     */
    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    /**
     *
     * @return country id
     */
    public int getCountryID() {
        return countryID;
    }

    /**
     *
     * @param countryID id to set
     */
    public void setCountryID(int countryID) {
        this.countryID = countryID;
    }

    /**
     *
     * @return country name
     */
    public String getCountryName() {
        return countryName;
    }

    /**
     *
     * @param countryName to set
     */
    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }
}
