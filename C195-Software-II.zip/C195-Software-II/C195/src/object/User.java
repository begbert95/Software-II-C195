package object;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

public class User {
    private int id;
    private String username;
    private String password;
    private Date createdDate;
    private String createdBy;
    private Date lastUpdate;
    private String lastUpdatedBy;

    /**
     *
     * @param id user id
     * @param username user name
     * @param password password
     * @param createdDate created date
     * @param createdBy created by
     * @param lastUpdate last update
     * @param lastUpdatedBy updated by
     */
    public User(int id, String username, String password, Date createdDate, String createdBy, Date lastUpdate, String lastUpdatedBy) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.createdDate = createdDate;
        this.createdBy = createdBy;
        this.lastUpdate = lastUpdate;
        this.lastUpdatedBy = lastUpdatedBy;
    }

    /**
     *
     * @param rs resultset constructor
     */
    public User(ResultSet rs){
        try{
            this.id = rs.getInt("User_ID");
            this.username = rs.getString("User_Name");
            this.password = rs.getString("Password");
            this.createdDate = rs.getTime("Create_Date");
            this.createdBy = rs.getString("Created_By");
            this.lastUpdate = rs.getTimestamp("Last_Update");
            this.lastUpdatedBy = rs.getString("Last_Updated_By");
        }
        catch (SQLException e){
            e.printStackTrace();
        }
    }

    /**
     *
     * @return id
     */
    public int getId() {
        return id;
    }

    /**
     *
     * @param id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     *
     * @return username
     */
    public String getUsername() {
        return username;
    }

    /**
     *
     * @return password
     */
    public String getPassword() {
        return password;
    }

}
