package object;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import helper.JDBC;

import java.sql.*;
import java.time.*;

public class AppointmentList {

    private static ObservableList<Appointment> allAppointments = FXCollections.observableArrayList();
    private static ObservableList<Appointment> monthlyAppointments = FXCollections.observableArrayList();
    private static ObservableList<Appointment> weeklyAppointments = FXCollections.observableArrayList();
    private static ObservableList<ZonedDateTime> openTimes = FXCollections.observableArrayList();
    private static Connection conn = JDBC.getConnection();

    /**
     *
     * @return observable list of all appointments
     */
    public static ObservableList<Appointment> getAllAppointments(){
        try{
            JDBC.makePreparedStatement("SELECT * FROM APPOINTMENTS", conn);
            ResultSet rs = JDBC.getPreparedStatement().executeQuery();

            allAppointments.clear();
            while(rs.next()){
                Appointment a = new Appointment(rs);

                for(Contact c : ContactList.getAllContacts()){
                    if(a.getContactID() == c.getId())
                        a.setContactName(c.getName());
                }

                allAppointments.add(a);
            }
        }
        catch (SQLException e){
            e.printStackTrace();
        }

        return allAppointments;
    }

    /**
     *
     * @return observable list of next month's appointments
     */
    public static ObservableList<Appointment> getMonthlyAppointments(){
        try{
            LocalDate todaysDate = LocalDate.now(ZoneId.systemDefault());

            JDBC.makePreparedStatement("SELECT * FROM APPOINTMENTS WHERE START >= ? and START <= ?", conn);
            PreparedStatement ps = JDBC.getPreparedStatement();
            ps.setDate(1, Date.valueOf(todaysDate));
            ps.setDate(2, Date.valueOf(todaysDate.plusMonths(1)));
            ResultSet rs = JDBC.getPreparedStatement().executeQuery();

            monthlyAppointments.clear();

            while(rs.next()){

                Appointment a = new Appointment(rs);

                for(Contact c : ContactList.getAllContacts()){
                    if(a.getContactID() == c.getId())
                        a.setContactName(c.getName());
                }

                monthlyAppointments.add(a);
            }
        }
        catch (SQLException e){
            e.printStackTrace();
        }

        return monthlyAppointments;
    }

    /**
     *
     * @return observable list of next weeks appointments
     */
    public static ObservableList<Appointment> getWeeklyAppointments(){
        try{
            LocalDate todaysDate = LocalDate.now(ZoneId.systemDefault());
            JDBC.makePreparedStatement("SELECT * FROM APPOINTMENTS WHERE START >= ? and START <= ?", conn);
            PreparedStatement ps = JDBC.getPreparedStatement();
            ps.setDate(1, Date.valueOf(todaysDate));
            ps.setDate(2, Date.valueOf(todaysDate.plusDays(7)));
            ResultSet rs = JDBC.getPreparedStatement().executeQuery();

            weeklyAppointments.clear();

            while(rs.next()){
                Appointment a = new Appointment(rs);

                for(Contact c : ContactList.getAllContacts()){
                    if(a.getContactID() == c.getId())
                        a.setContactName(c.getName());
                }

                weeklyAppointments.add(a);
            }
        }
        catch (SQLException e){
            e.printStackTrace();
        }

        return weeklyAppointments;
    }

    /**
     *
     * @return next upcoming appointment within the next week
     */
    public static Appointment getNextAppointment(){
        if(getWeeklyAppointments().isEmpty())
            return null;

        Appointment lowestStart = weeklyAppointments.get(weeklyAppointments.size() -1);

        for(Appointment a : weeklyAppointments) {
            if (a.getStart().isBefore(lowestStart.getStart()) && a.getStart().isAfter(Instant.now()))
                lowestStart = a;

        }
        return lowestStart;
    }

    /**
     *
     * @return the largest appointment id + 1 from the database
     */
    public static int getNextAppointmentID(){
        try{
            JDBC.makePreparedStatement("SELECT MAX(APPOINTMENT_ID) FROM APPOINTMENTS", conn);
            PreparedStatement ps = JDBC.getPreparedStatement();
            ResultSet rs = ps.executeQuery();
            if(rs.next()){
                return rs.getInt(1) + 1;
            }
        }
        catch  (SQLException e){
            e.printStackTrace();
        }
        return 0;
    }

    /**
     *
     * @param id id to lookup
     * @return appointment with corresponding ID
     */
    public static Appointment getAppointment(int id){
        try{
            JDBC.makePreparedStatement("Select * FROM APPOINTMENTS WHERE APPOINTMENT_ID = ?", conn);
            PreparedStatement ps = JDBC.getPreparedStatement();
            ps.setInt(1, id);

            ResultSet rs = ps.executeQuery();

            if(rs.next()){
                return new Appointment(rs);
            }
            else
                return null;
        }
        catch (SQLException e){
            e.printStackTrace();
            return null;
        }
    }

    /**
     *
     * @param a appointment
     * @return boolean if delete was successful
     */
    public static boolean deleteAppointment (Appointment a){
        try{
            JDBC.makePreparedStatement("DELETE FROM APPOINTMENTS WHERE APPOINTMENT_ID = ?", conn);
            PreparedStatement ps = JDBC.getPreparedStatement();
            ps.setInt(1, a.getAppointmentID());

            int i = ps.executeUpdate();

            if(i == 1){
                getAllAppointments();
                return true;
            }
            else{
                return false;
            }
        }
        catch (SQLException e){
            e.printStackTrace();
            return false;
        }
    }

    /**
     *
     * @param zonedDateTime date entered, at start of day
     * @return observable list of available appointment times
     */
    public static ObservableList<ZonedDateTime> getOpenTimes(ZonedDateTime zonedDateTime){

        LocalDate easternDate = zonedDateTime.withZoneSameInstant(ZoneId.of("America/New_York")).toLocalDate();

        for(int i = 8; i < 22; i++){
            ZonedDateTime returnDateTime = ZonedDateTime.of(easternDate.atTime(i, 0), ZoneId.of("America/New_York"));

            openTimes.add(returnDateTime);
        }

        try{
            JDBC.makePreparedStatement("SELECT Start FROM APPOINTMENTS WHERE Start >= ? AND Start < ? ", conn);
            PreparedStatement ps = JDBC.getPreparedStatement();
            ps.setDate(1, Date.valueOf(zonedDateTime.toLocalDate()));
            ps.setDate(2, Date.valueOf(zonedDateTime.toLocalDate().plusDays(1)));
            ResultSet rs = ps.executeQuery();

            while (rs.next()){
                ZonedDateTime timeCheck = rs.getObject("Start", LocalDateTime.class).atZone(ZoneId.of("UTC"));

                openTimes.remove(timeCheck.withZoneSameInstant(ZoneId.of("America/New_York")));
            }
            return openTimes;
        }
        catch (SQLException e){
            e.printStackTrace();
            return null;
        }
    }

    /**
     *
     * @param name contact name
     * @return observable list of appointments with the contact's name attached
     */
    public static ObservableList<Appointment> getContactSchedule(String name){
        Contact c = ContactList.lookupContact(name);
        ObservableList<Appointment> contactAppointments = FXCollections.observableArrayList();
        try{
            JDBC.makePreparedStatement("SELECT * FROM Appointments where Contact_ID = ?", conn);
            PreparedStatement preparedStatement = JDBC.getPreparedStatement();
            preparedStatement.setInt(1, c.getId());
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()){
                Appointment a = new Appointment(resultSet);
                contactAppointments.add(a);
            }
            return contactAppointments;
        }
        catch (SQLException e){
            e.printStackTrace();
            return null;
        }

    }

    /**
     *
     * @return observable list of observable lists for the report table
     */
    public static ObservableList<ObservableList> getAppointmentTypes(){
        try{
            JDBC.makePreparedStatement("SELECT TYPE, COUNT(*) FROM APPOINTMENTS GROUP BY TYPE", conn);
            ResultSet resultSet = JDBC.getPreparedStatement().executeQuery();


            ObservableList<ObservableList> data = FXCollections.observableArrayList();

            while (resultSet.next()){
                ObservableList<String> row = FXCollections.observableArrayList();

                row.add(resultSet.getString(1));
                row.add(resultSet.getString(2));
                data.add(row);
            }
            return data;
        }
        catch (SQLException e){
            return null;
        }
    }
}
