package object;

import helper.JDBC;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CountryList {

    /**
     *
     * @return observable list of all countries
     */
    public static ObservableList<Country> getAllCountries(){
        ObservableList<Country> allCountries = FXCollections.observableArrayList();
        Connection conn = JDBC.getConnection();
        try{
            JDBC.makePreparedStatement("SELECT * FROM COUNTRIES", conn);
            ResultSet rs = JDBC.getPreparedStatement().executeQuery();

            allCountries.clear();
            while(rs.next()){
                Country c = new Country(rs);

                allCountries.add(c);
            }
        }
        catch (SQLException e){
            e.printStackTrace();
        }

        return allCountries;
    }

    /**
     *
     * @param id country id
     * @return country
     */
    public static Country lookupCountry(int id){
        for(Country c : getAllCountries()){
            if(c.getId() == id)
                return  c;
        }
        return null;
    }

    /**
     *
     * @param name country name
     * @return country
     */
    public static Country lookupCountry(String name){

        for(Country c : getAllCountries())
            if (c.getName().equals(name))
                return c;

        return null;
    }
}
