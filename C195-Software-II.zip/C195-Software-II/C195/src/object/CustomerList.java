package object;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import helper.JDBC;

import java.sql.*;

public class CustomerList {
    private static final Connection conn = JDBC.getConnection();

    /**
     *
     * @return observable list of all customers
     */
    public static ObservableList<Customer> getAllCustomers(){
        ObservableList<Customer> allCustomers = FXCollections.observableArrayList();
        try{
            JDBC.makePreparedStatement("SELECT * FROM CUSTOMERS", conn);
            ResultSet rs = JDBC.getPreparedStatement().executeQuery();
            allCustomers.clear();

            while(rs.next()){
                Customer c = new Customer(rs);

                allCustomers.add(c);
            }
        }
        catch (SQLException e){
            e.printStackTrace();
        }

        return allCustomers;
    }

    /**
     *
     * @param i customer id
     * @return customer
     */
    public static Customer lookupCustomer(int i){
        for(Customer c : getAllCustomers()){
            if(c.getCustomerID() == i){
                return c;
            }
        }
        return null;
    }

    /**
     *
     * @param s customer name
     * @return customer
     */
    public static Customer lookupCustomer(String s){
        for(Customer c : getAllCustomers()){
            if(c.getName().contains(s)){
                return c;
            }
        }
        return null;
    }

    /**
     *
     * @return observable list of observable lists for the divisions and number of customers in them
     */
    public static ObservableList<ObservableList> getLocationSummary(){
        try{
            JDBC.makePreparedStatement("SELECT Division, COUNT(*) FROM CUSTOMERS join first_level_divisions on customers.Division_ID = first_level_divisions.Division_ID GROUP BY division", conn);
            ResultSet resultSet = JDBC.getPreparedStatement().executeQuery();


            ObservableList<ObservableList> data = FXCollections.observableArrayList();

            while (resultSet.next()){
                ObservableList<String> row = FXCollections.observableArrayList();

                row.add(resultSet.getString(1));
                row.add(resultSet.getString(2));
                data.add(row);
            }
            return data;
        }
        catch (SQLException e){
            return null;
        }
    }

    /**
     *
     * @return highest customer id + 1
     */
    public static int getNextCustomerID(){
        try{
            JDBC.makePreparedStatement("SELECT MAX(Customer_ID) FROM Customers", conn);
            PreparedStatement ps = JDBC.getPreparedStatement();
            ResultSet rs = ps.executeQuery();
            if(rs.next()){
                return rs.getInt(1) + 1;
            }
        }
        catch  (SQLException e){
            e.printStackTrace();
        }
        return 0;
    }
}
