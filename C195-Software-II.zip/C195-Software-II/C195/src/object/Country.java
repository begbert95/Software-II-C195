package object;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;

public class Country {
    private int id;
    private String name;
    private LocalDateTime createDate;
    private String createdBy;
    private LocalDateTime lastUpdate;
    private String updatedBy;
    private ObservableList<Division> childDivisions = FXCollections.observableArrayList();

    /**
     *
     * @param id country id
     * @param name country name
     * @param createDate country createdate
     * @param createdBy country createdby
     * @param lastUpdate country last update
     * @param updatedBy country updated by
     */
    public Country(int id, String name, LocalDateTime createDate, String createdBy, LocalDateTime lastUpdate, String updatedBy) {
        this.id = id;
        this.name = name;
        this.createDate = createDate;
        this.createdBy = createdBy;
        this.lastUpdate = lastUpdate;
        this.updatedBy = updatedBy;

    }

    /**
     *
     * @param rs result set to create country
     */
    public Country(ResultSet rs){
        try{
            this.id = rs.getInt("Country_ID");
            this.name = rs.getString("Country");
            this.createDate = rs.getObject("Create_Date", LocalDateTime.class);
            this.createdBy = rs.getString("Created_By");
            this.lastUpdate = rs.getObject("Last_Update", LocalDateTime.class);
            this.updatedBy = rs.getString("Last_Updated_By");
        }
        catch (SQLException e){
            e.printStackTrace();
        }
    }

    /**
     * empty constructor
     */
    public Country() {

    }

    /**
     *
     * @return country id
     */
    public int getId() {
        return id;
    }

    /**
     *
     * @param id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     *
     * @return name
     */
    public String getName() {
        return name;
    }

    /**
     *
     * @param name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     *
     * @return get created date
     */
    public LocalDateTime getCreateDate() {
        return createDate;
    }

    /**
     *
     * @param createDate to set
     */
    public void setCreateDate(LocalDateTime createDate) {
        this.createDate = createDate;
    }

    /**
     *
     * @return created by
     */
    public String getCreatedBy() {
        return createdBy;
    }

    /**
     *
     * @param createdBy to set
     */
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    /**
     *
     * @return last update
     */
    public LocalDateTime getLastUpdate() {
        return lastUpdate;
    }

    /**
     *
     * @param lastUpdate to set
     */
    public void setLastUpdate(LocalDateTime lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    /**
     *
     * @return updated by
     */
    public String getUpdatedBy() {
        return updatedBy;
    }

    /**
     *
     * @param updatedBy to set
     */
    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    /**
     *
     * @return observable list of all divisions for the country
     */
    public ObservableList<Division> getChildDivisions(){
        ObservableList<Division> childDivisions = FXCollections.observableArrayList();
        for(Division d : DivisionList.getAllDivisions())
            if(d.getCountryID() == id)
                childDivisions.add(d);

        return childDivisions;
    }
}
