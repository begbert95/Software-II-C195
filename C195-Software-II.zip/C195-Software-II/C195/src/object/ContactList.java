package object;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import helper.JDBC;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ContactList {
    private static ObservableList<Contact> allContacts = FXCollections.observableArrayList();
    private static Connection conn = JDBC.getConnection();

    /**
     *
     * @return observable list of contacts
     */
    public static ObservableList<Contact> getAllContacts(){
        try{
            JDBC.makePreparedStatement("SELECT * FROM CONTACTS", conn);
            ResultSet rs = JDBC.getPreparedStatement().executeQuery();

            allContacts.clear();

            while(rs.next()){
                Contact c = new Contact(rs);
                allContacts.add(c);
            }
        }
        catch (SQLException e){
            e.printStackTrace();
        }
        return allContacts;
    }

    /**
     *
     * @param c contact to add
     */
    public static void addContact(Contact c){
        allContacts.add(c);
    }

    /**
     *
     * @param i contact id
     * @return contact
     */
    public static Contact lookupContact(int i){
        for(Contact c : getAllContacts()){
            if(c.getId() == i)
                return c;
        }
        return null;
    }

    /**
     *
     * @param s contact name
     * @return contact
     */
    public static Contact lookupContact(String s){
        for(Contact c : getAllContacts())
            if(c.getName().contains(s))
                return c;


        return null;
    }
}
