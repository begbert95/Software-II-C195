package object;

import helper.JDBC;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DivisionList {

    /**
     * @return observable list of all divisions
     */
    public static ObservableList<Division> getAllDivisions() {
        ObservableList<Division> allDivisions = FXCollections.observableArrayList();
        Connection conn = JDBC.getConnection();

        try {
            JDBC.makePreparedStatement("SELECT * FROM FIRST_LEVEL_DIVISIONS", conn);
            ResultSet rs = JDBC.getPreparedStatement().executeQuery();

            allDivisions.clear();

            while (rs.next()) {
                Division d = new Division(rs);

                allDivisions.add(d);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return allDivisions;
    }

    /**
     * @param id division id
     * @return division
     */
    public static Division lookupDivision(int id) {
        for (Division d : getAllDivisions()) {
            if (d.getDivID() == id)
                return d;
        }
        return null;
    }

    /**
     * @param name of division
     * @return division
     */
    public static Division lookupDivision(String name) {

        for (Division d : getAllDivisions())
            if (d.getName().equals(name))
                return d;

        return null;
    }
}
