package object;

import java.sql.ResultSet;
import java.sql.SQLException;

public class Contact {
    private int id;
    private String name;
    private String email;

    /**
     *
     * @param id contact id
     * @param name contact name
     * @param email contact email
     */
    public Contact(int id, String name, String email) {
        this.id = id;
        this.name = name;
        this.email = email;
        ContactList.addContact(this);
    }

    /**
     *
     * @param rs constructs based on resultset
     */
    public Contact(ResultSet rs){
        try{
            this.id = rs.getInt("Contact_ID");
            this.name = rs.getString("Contact_Name");
            this.email = rs.getString("Email");
        }
        catch (SQLException e){
            e.printStackTrace();
        }
    }

    /**
     *
     * @return id
     */
    public int getId() {
        return id;
    }

    /**
     *
     * @param id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     *
     * @return name
     */
    public String getName() {
        return name;
    }

    /**
     *
     * @param name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     *
     * @return email
     */
    public String getEmail() {
        return email;
    }

    /**
     *
     * @param email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }
}
