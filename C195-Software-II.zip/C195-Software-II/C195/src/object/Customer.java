package object;

import helper.JDBC;

import java.sql.*;
import java.time.Instant;

public class Customer {
    private int customerID;
    private String name;
    private String address;
    private String zip;
    private String phone;
    private Instant createdDate;
    private String createdBy;
    private Instant updatedDate;
    private String updatedBy;
    private int divisionID;
    private String divisionName;

    private final Connection conn = JDBC.getConnection();

    /**
     *
     * @param customerID customer id
     * @param name customer name
     * @param address customer address
     * @param zip customer zip code
     * @param phone customer phone number
     * @param createdDate customer created date
     * @param createdBy user that created customer
     * @param updatedDate customer updated date
     * @param updatedBy user that updated customer
     * @param divisionID division id
     */
    public Customer(
            int customerID,
            String name,
            String address,
            String zip,
            String phone,
            Instant createdDate,
            String createdBy,
            Instant updatedDate,
            String updatedBy,
            int divisionID
    ) {
        this.customerID = customerID;
        this.name = name;
        this.address = address;
        this.zip = zip;
        this.phone = phone;
        this.createdDate = createdDate;
        this.createdBy = createdBy;
        this.updatedDate = updatedDate;
        this.updatedBy = updatedBy;
        this.divisionID = divisionID;
        this.divisionName = DivisionList.lookupDivision(divisionID).getName();
    }

    /**
     *
     * @param rs result set used for constructor
     */
    public Customer(ResultSet rs) {
        try {
            customerID = rs.getInt("Customer_ID");
            name = rs.getString("Customer_Name");
            address = rs.getString("Address");
            zip = rs.getString("Postal_Code");
            phone = rs.getString("Phone");
            createdDate = rs.getTimestamp("Create_Date").toInstant();
            createdBy = rs.getString("Created_By");
            updatedDate = rs.getTimestamp("Last_Update").toInstant();
            updatedBy = rs.getString("Last_Updated_By");
            divisionID = rs.getInt("Division_ID");
            divisionName = DivisionList.lookupDivision(divisionID).getName();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    /**
     * empty constructor
     */
    public Customer() {
    }

    /**
     *
     * @return customer id
     */
    public int getCustomerID() {
        return customerID;
    }

    /**
     *
     * @param customerID to set
     */
    public void setCustomerID(int customerID) {
        this.customerID = customerID;
    }

    /**
     *
     * @return name
     */
    public String getName() {
        return name;
    }

    /**
     *
     * @param name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     *
     * @return address
     */
    public String getAddress() {
        return address;
    }

    /**
     *
     * @param address to set
     */
    public void setAddress(String address) {
        this.address = address;
    }

    /**
     *
     * @return zipcode
     */
    public String getZip() {
        return zip;
    }

    /**
     *
     * @param zip to set
     */
    public void setZip(String zip) {
        this.zip = zip;
    }

    /**
     *
     * @return phone number
     */
    public String getPhone() {
        return phone;
    }

    /**
     *
     * @param phone to set
     */
    public void setPhone(String phone) {
        this.phone = phone;
    }

    /**
     *
     * @return created date
     */
    public Instant getCreatedDate() {
        return createdDate;
    }

    /**
     *
     * @param createdDate to set
     */
    public void setCreatedDate(Instant createdDate) {
        this.createdDate = createdDate;
    }

    /**
     *
     * @return created by user
     */
    public String getCreatedBy() {
        return createdBy;
    }

    /**
     *
     * @param createdBy user to set
     */
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    /**
     *
     * @return updated date
     */
    public Instant getUpdatedDate() {
        return updatedDate;
    }

    /**
     *
     * @param updatedDate to set
     */
    public void setUpdatedDate(Instant updatedDate) {
        this.updatedDate = updatedDate;
    }

    /**
     *
     * @return user who updated
     */
    public String getUpdatedBy() {
        return updatedBy;
    }

    /**
     *
     * @param updatedBy user to set
     */
    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    /**
     *
     * @return division ID
     */
    public int getDivisionID() {
        return divisionID;
    }

    /**
     *
     * @param divisionID to set
     */
    public void setDivisionID(int divisionID) {
        this.divisionID = divisionID;
    }

    /**
     *
     * @return division name
     */
    public String getDivisionName() {
        return divisionName;
    }

    /**
     *
     * @param divisionName to set
     */
    public void setDivisionName(String divisionName) {
        this.divisionName = divisionName;
    }

    /**
     *
     * @return country name
     */
    public String getCountryName() {
        Division d = DivisionList.lookupDivision(divisionID);
        return d.getCountryName();
    }

    /**
     *
     * @return boolean on sql results
     */
    public boolean deleteFromDatabase() {
        try {
            Connection conn = JDBC.getConnection();
            JDBC.makePreparedStatement("DELETE FROM CUSTOMERS WHERE Customer_ID = ?", conn);
            PreparedStatement preparedStatement = JDBC.getPreparedStatement();
            preparedStatement.setInt(1, customerID);
            return preparedStatement.executeUpdate() == 1;
        } catch (SQLException e) {
            return false;
        }
    }

    /**
     *
     * @return boolean on sql output
     */
    public boolean writeToDatabase() {
        try {

            JDBC.makePreparedStatement("SELECT Customer_ID FROM CUSTOMERS WHERE Customer_ID = ?", conn);

            PreparedStatement queryPreparedStatement = JDBC.getPreparedStatement();
            queryPreparedStatement.setInt(1, customerID);
            ResultSet resultSet = queryPreparedStatement.executeQuery();

            if (resultSet.next()) {
                String query =
                        "UPDATE CUSTOMERS SET " +
                                "Customer_Name = ?, " +
                                "Address = ?, " +
                                "Postal_Code = ?, " +
                                "Phone = ?, " +
                                "Last_Update = ?, " +
                                "Last_Updated_By = ?, " +
                                "Division_ID = ? " +
                                "WHERE Customer_ID = ?";
                JDBC.makePreparedStatement(query, conn);
                PreparedStatement updatePreparedStatement = JDBC.getPreparedStatement();
                updatePreparedStatement.setString(1, name);
                updatePreparedStatement.setString(2, address);
                updatePreparedStatement.setString(3, zip);
                updatePreparedStatement.setString(4, phone);
                updatePreparedStatement.setTimestamp(5, Timestamp.from(updatedDate));
                updatePreparedStatement.setString(6, updatedBy);
                updatePreparedStatement.setInt(7, divisionID);
                updatePreparedStatement.setInt(8, customerID);

                return updatePreparedStatement.executeUpdate() == 1;
            } else {
                String query = "INSERT INTO CUSTOMERS VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                JDBC.makePreparedStatement(query, conn);
                PreparedStatement updatePreparedStatement = JDBC.getPreparedStatement();
                updatePreparedStatement.setInt(1, customerID);
                updatePreparedStatement.setString(2, name);
                updatePreparedStatement.setString(3, address);
                updatePreparedStatement.setString(4, zip);
                updatePreparedStatement.setString(5, phone);
                updatePreparedStatement.setTimestamp(6, Timestamp.from(createdDate));
                updatePreparedStatement.setString(7, createdBy);
                updatePreparedStatement.setTimestamp(8, Timestamp.from(updatedDate));
                updatePreparedStatement.setString(9, updatedBy);
                updatePreparedStatement.setInt(10, divisionID);
                return updatePreparedStatement.executeUpdate() == 1;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     *
     * @return boolean if there are any appointments for a customer
     */
    public boolean isSafeToDelete() {
        try {
            JDBC.makePreparedStatement("SELECT * FROM APPOINTMENTS WHERE CUSTOMER_ID = ?", conn);
            PreparedStatement ps = JDBC.getPreparedStatement();
            ps.setInt(1, customerID);
            ResultSet rs = ps.executeQuery();


            return !rs.next();
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     *
     * @return boolean if all fields have been properly set
     */
    public boolean validate() {
        if (customerID == 0)
            return false;
        if (name.isEmpty())
            return false;
        if (address.isEmpty())
            return false;
        if (zip.isEmpty())
            return false;
        if (phone.isEmpty())
            return false;
        if (createdDate == null)
            return false;
        if (createdBy.isEmpty())
            return false;
        if (updatedDate == null)
            return false;
        if (updatedBy.isEmpty())
            return false;
        if (divisionID == 0)
            return false;
        if (divisionName.isEmpty())
            return false;


        return true;
    }
}
