package object;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import helper.JDBC;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Objects;

public class UserList {
    private static final Connection conn = JDBC.getConnection();

    /**
     *
     * @return observable list of all users
     */
    private static ObservableList<User> getAllUsers(){
        ObservableList<User> allUsers = FXCollections.observableArrayList();
        try{
            JDBC.makePreparedStatement("SELECT * FROM USERS", conn);
            ResultSet rs = JDBC.getPreparedStatement().executeQuery();

            allUsers.clear();

            while(rs.next()){
                User u = new User(rs);
                allUsers.add(u);
            }
            return allUsers;
        }
        catch (SQLException e){
            e.printStackTrace();
            return null;
        }
    }

    /**
     *
     * @param username to lookup
     * @return user
     */
    public static User lookupUser(String username){
        for(User u: Objects.requireNonNull(getAllUsers())){
            if(username.equals(u.getUsername())){
                return u;
            }
        }
        return null;
    }

    /**
     *
     * @return observable list of observable lists showing how many appointments each user created
     */
    public static ObservableList<ObservableList> getUserWork(){
        try {
            JDBC.makePreparedStatement("SELECT user_name, count(appointment_ID) from users join appointments on users.User_ID = appointments.User_ID group by user_name", conn);
            ResultSet resultSet = JDBC.getPreparedStatement().executeQuery();

            ObservableList<ObservableList> data = FXCollections.observableArrayList();

            while (resultSet.next()){
                ObservableList<String> row = FXCollections.observableArrayList();

                row.add(resultSet.getString(1));
                row.add(resultSet.getString(2));
                data.add(row);
            }
            return data;
        }
        catch (SQLException e){
            e.printStackTrace();
            return null;
        }

    }
}
