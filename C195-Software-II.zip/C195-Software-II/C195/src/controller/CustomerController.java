package controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Rectangle2D;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Screen;
import javafx.stage.Stage;
import object.*;

import java.io.IOException;
import java.net.URL;
import java.time.Instant;
import java.util.ResourceBundle;

public class CustomerController implements Initializable {

    //region ************************* FXML Variables *************************

    @FXML
    private TextField addressField;

    @FXML
    private Button cancelButton;

    @FXML
    private ComboBox<String> countryCombo;

    @FXML
    private ComboBox<String> divisionCombo;

    @FXML
    private TextField idField;

    @FXML
    private Label msgBox;

    @FXML
    private TextField nameField;

    @FXML
    private TextField phoneField;

    @FXML
    private TextField postField;

    @FXML
    private Button saveButton;

    //endregion ************************* FXML Variables *************************

    private Customer customer = new Customer();

    /**
     * collects, validates, then saves data to the database
     */
    @FXML
    private void onSave() {
        customer.setName(nameField.getText());
        customer.setAddress(addressField.getText());
        customer.setZip(postField.getText());
        customer.setPhone(phoneField.getText());

        if (customer.getCreatedBy() == null) {
            customer.setCreatedBy(LoginController.currentUser);
            customer.setCreatedDate(Instant.now());
        }
        customer.setUpdatedBy(LoginController.currentUser);
        customer.setUpdatedDate(Instant.now());

        customer.setDivisionName(divisionCombo.getValue());
        customer.setDivisionID(DivisionList.lookupDivision(customer.getDivisionName()).getDivID());


        if (customer.validate()) {
            if (customer.writeToDatabase())
                toHome();
            else
                showError("Customer has valid data, but cannot be written to database!");
        } else
            showError("Unable to validate customer! Please validate the information!");
    }

    /**
     * loads the main screen
     */
    @FXML
    private void toHome() {
        try {
            Stage stage = (Stage) cancelButton.getScene().getWindow();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("../view/homeView.fxml"));
            Parent root = loader.load();

            Scene scene = new Scene(root);
            stage.setTitle("Home");
            stage.setScene(scene);
            stage.centerOnScreen();

            Rectangle2D screenBounds = Screen.getPrimary().getVisualBounds();

            stage.setX((screenBounds.getWidth() - stage.getWidth()) / 2);
            stage.setY((screenBounds.getHeight() - stage.getHeight()) / 2);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * @param id customer ID to show
     *           <p>
     *           shows a customer selected from the previous screen
     */
    public void showCustomer(int id) {
        customer = CustomerList.lookupCustomer(id);

        if (customer == null) {
            showError("Error loading customer with ID: " + id);
        }

        idField.setText(String.valueOf(customer.getCustomerID()));
        nameField.setText(customer.getName());
        addressField.setText(customer.getAddress());
        postField.setText(customer.getZip());
        phoneField.setText(customer.getPhone());
        countryCombo.setValue(DivisionList.lookupDivision(customer.getDivisionID()).getCountryName());
        divisionCombo.setValue(customer.getDivisionName());
    }

    /**
     * puts countries into the combo box
     */
    private void populateCountryComboBox() {
        for (Country c : CountryList.getAllCountries()) {
            countryCombo.getItems().add(c.getName());
        }
    }

    /**
     * puts Division info into the combo box
     */
    @FXML
    private void populateDivisionComboBox() {
        Country country = CountryList.lookupCountry(countryCombo.getValue());

        divisionCombo.getItems().clear();

        if (country != null)
            for (Division d : country.getChildDivisions())
                divisionCombo.getItems().add(d.getName());
        else
            showError("Please select a country!");
    }

    /**
     * @param url
     * @param resourceBundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        populateCountryComboBox();
        customer.setCustomerID(CustomerList.getNextCustomerID());
        idField.setText(String.valueOf(customer.getCustomerID()));
    }

    /**
     * @param s small method to display an "error". Takes in a string to display
     */
    private void showError(String s) {
        msgBox.setStyle("-fx-text-fill: red");
        msgBox.setText(s);
    }

    /**
     * @param s small method to display a message. Takes in a string to display
     */
    private void showMessage(String s) {
        msgBox.setStyle("-fx-text-fill: black");
        msgBox.setText(s);
    }
}
