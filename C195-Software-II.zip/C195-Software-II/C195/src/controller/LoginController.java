package controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Rectangle2D;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Screen;
import javafx.stage.Stage;
import object.User;
import object.UserList;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.time.Instant;
import java.time.ZoneId;
import java.util.Locale;
import java.util.ResourceBundle;

public class LoginController implements Initializable {

    @FXML
    private Button loginButton;
    @FXML
    private Button cancelButton;
    @FXML
    private Label msgBox;
    @FXML
    private Label zoneIdLabel;
    @FXML
    private Label userLabel;
    @FXML
    private Label passLabel;
    @FXML
    private TextField userField;
    @FXML
    private PasswordField passField;


    private ResourceBundle rb;
    public static String currentUser;

    /**
     *
     * @param url
     * @param resourceBundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        Locale loc = Locale.getDefault();
        rb = ResourceBundle.getBundle("Languages", loc);
        zoneIdLabel.setText(String.valueOf(ZoneId.systemDefault()));

        loginButton.setText(rb.getString("login"));
        cancelButton.setText(rb.getString("cancel"));
        userField.setPromptText(rb.getString("username"));
        passField.setPromptText(rb.getString("password"));
        userLabel.setText(rb.getString("username"));
        passLabel.setText(rb.getString("password"));
    }

    /**
     * loads main screen
     */
    private void toHomeScreen() {
        try {
            Stage stage = (Stage) loginButton.getScene().getWindow();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("../view/homeView.fxml"));
            Parent root = loader.load();

            Scene scene = new Scene(root);
            stage.setTitle("Home");
            stage.setScene(scene);
            stage.centerOnScreen();

            Rectangle2D screenBounds = Screen.getPrimary().getVisualBounds();

            stage.setX((screenBounds.getWidth() - stage.getWidth()) / 2);
            stage.setY((screenBounds.getHeight() - stage.getHeight()) / 2);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     *
     * @param b whether login was successful
     * @param user entered username
     * @param pass entered password
     *
     * login logs
     */
    private void writeLogin(boolean b, String user, String pass) {
        try {
            FileWriter fw = new FileWriter("login_activity.txt", true);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter pw = new PrintWriter(bw);

            pw.println("************************************************");
            pw.println("******            Login Attempt           ******");
            pw.println("************************************************");
            pw.println("Success = " + b);
            pw.println("Entered username: " + user);
            pw.println("Entered password: " + pass);
            pw.println("Time: " + Instant.now());
            pw.println("************************************************\n");

            pw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * on action method to check login credentials
     */
    @FXML
    private void onLogin() {

        String user = userField.getText();
        String pass = passField.getText();

        User u = UserList.lookupUser(user);

        if(u == null){
            showError(rb.getString("error"));
            writeLogin(false, user, pass);
        }
        else if (u.getUsername().equals(user) && u.getPassword().equals(pass)) {
            writeLogin(true, user, pass);
            showMessage(rb.getString("success"));
            currentUser = user;
            toHomeScreen();
        } else {
            writeLogin(false, user, pass);
            showError(rb.getString("error"));
        }
    }

    /**
     * graceful exit
     */
    public void onCancel() {
        System.exit(0);
    }

    /**
     *
     * @param s message to display
     */
    private void showError(String s) {
        msgBox.setStyle("-fx-text-fill: red");
        msgBox.setText(s);
    }

    /**
     *
     * @param s message to display
     */
    private void showMessage(String s) {
        msgBox.setStyle("-fx-text-fill: black");
        msgBox.setText(s);
    }
}
