package controller;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.util.Callback;
import object.*;

import java.io.IOException;
import java.net.URL;
import java.time.Instant;
import java.util.ResourceBundle;

public class HomeController implements Initializable {

    //region ************************ FXML Objects ************************
    @FXML
    private TableView locationSummaryTable;
    @FXML
    private TableColumn locationSummaryDivisionColumn;
    @FXML
    private TableColumn locationSummaryCountColumn;
    @FXML
    private TableView userWorkTable;
    @FXML
    private TableColumn userWorkNameColumn;
    @FXML
    private TableColumn userWorkCountColumn;
    @FXML
    private TableView appointmentTypeTable;
    @FXML
    private TableColumn appointmentTypeTypeColumn;
    @FXML
    private TableColumn appointmentTypeCountColumn;

    @FXML
    private TableColumn custNameColumn;
    @FXML
    private TableColumn custAddressColumn;
    @FXML
    private TableColumn custPhoneColumn;
    @FXML
    private TableColumn appAppIDColumn;
    @FXML
    private TableColumn appTitleColumn;
    @FXML
    private TableColumn appDescriptionColumn;
    @FXML
    private TableColumn appLocationColumn;
    @FXML
    private TableColumn appContactColumn;
    @FXML
    private TableColumn appTypeColumn;
    @FXML
    private TableColumn appStartColumn;
    @FXML
    private TableColumn appEndColumn;
    @FXML
    private TableColumn appCustIDColumn;
    @FXML
    private TableColumn appUserIDColumn;
    @FXML
    private TableColumn custFirstLevelDivisionColumn;
    @FXML
    private TableColumn custCountryColumn;
    @FXML
    private Button appDelButton;

    @FXML
    private Button appEditButton;

    @FXML
    private Button appNewButton;

    @FXML
    private TableView appointmentTable;

    @FXML
    private Button cDelButton;

    @FXML
    private Button cEditButton;

    @FXML
    private Button cNewButton;

    @FXML
    private TableView customerTable;
    @FXML
    private TableView contactTable;
    @FXML
    private TableColumn contactAppointmentIdColumn;
    @FXML
    private TableColumn contactStartColumn;
    @FXML
    private TableColumn contactEndColumn;
    @FXML
    private TableColumn contactCustomerIdColumn;
    @FXML
    private TableColumn contactDescriptionColumn;
    @FXML
    private TableColumn contactTitleColumn;
    @FXML
    private ComboBox<String> contactCombo;
    @FXML
    private RadioButton monthRadio;
    @FXML
    private RadioButton weekRadio;
    @FXML
    private RadioButton allRadio;
    @FXML
    private Label appMsgBox;
    @FXML
    private Label custMsgBox;

    //endregion ************************ FXML Objects ************************

    /**
     * @param url
     * @param resourceBundle sets up the main page
     *
     * uses lambda expressions to simplify code. Since each object is only used in this one instance, it also saves resources
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        //customer table
        custNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        custAddressColumn.setCellValueFactory(new PropertyValueFactory<>("address"));
        custFirstLevelDivisionColumn.setCellValueFactory(new PropertyValueFactory<>("divisionName"));
        custCountryColumn.setCellValueFactory(new PropertyValueFactory<>("countryName"));
        custPhoneColumn.setCellValueFactory(new PropertyValueFactory<>("phone"));
        customerTable.setItems(CustomerList.getAllCustomers());


        //appointment table
        appAppIDColumn.setCellValueFactory(new PropertyValueFactory<>("appointmentID"));
        appTitleColumn.setCellValueFactory(new PropertyValueFactory<>("title"));
        appDescriptionColumn.setCellValueFactory(new PropertyValueFactory<>("description"));
        appLocationColumn.setCellValueFactory(new PropertyValueFactory<>("location"));
        appTypeColumn.setCellValueFactory(new PropertyValueFactory<>("type"));
        appStartColumn.setCellValueFactory(new PropertyValueFactory<>("localStartDate"));
        appEndColumn.setCellValueFactory(new PropertyValueFactory<>("localEndDate"));
        appCustIDColumn.setCellValueFactory(new PropertyValueFactory<>("customerID"));
        appUserIDColumn.setCellValueFactory(new PropertyValueFactory<>("userID"));
        appContactColumn.setCellValueFactory(new PropertyValueFactory<>("contactName"));
        appointmentTable.setItems(AppointmentList.getAllAppointments());


        //appointment type
        // uses lambda expressions to simplify code. Since each object is only used in this one instance, it also saves resources
        appointmentTypeTypeColumn.setCellValueFactory((
                Callback<TableColumn.CellDataFeatures<ObservableList, String>, ObservableValue<String>>) param
                -> new SimpleStringProperty(param.getValue().get(0).toString()));
        appointmentTypeCountColumn.setCellValueFactory((
                Callback<TableColumn.CellDataFeatures<ObservableList, String>, ObservableValue<String>>) param
                -> new SimpleStringProperty(param.getValue().get(1).toString()));
        appointmentTypeTable.setItems(AppointmentList.getAppointmentTypes());


        //user work
        // uses lambda expressions to simplify code. Since each object is only used in this one instance, it also saves resources
        userWorkNameColumn.setCellValueFactory((
                Callback<TableColumn.CellDataFeatures<ObservableList, String>, ObservableValue<String>>) param
                -> new SimpleStringProperty(param.getValue().get(0).toString()));
        userWorkCountColumn.setCellValueFactory((
                Callback<TableColumn.CellDataFeatures<ObservableList, String>, ObservableValue<String>>) param
                -> new SimpleStringProperty(param.getValue().get(1).toString()));
        userWorkTable.setItems(UserList.getUserWork());


        //location summary
        // uses lambda expressions to simplify code. Since each object is only used in this one instance, it also saves resources
        locationSummaryDivisionColumn.setCellValueFactory((
                Callback<TableColumn.CellDataFeatures<ObservableList, String>, ObservableValue<String>>) param
                -> new SimpleStringProperty(param.getValue().get(0).toString()));
        locationSummaryCountColumn.setCellValueFactory((
                Callback<TableColumn.CellDataFeatures<ObservableList, String>, ObservableValue<String>>) param
                -> new SimpleStringProperty(param.getValue().get(1).toString()));
        locationSummaryTable.setItems(CustomerList.getLocationSummary());


        //contact schedule
        contactAppointmentIdColumn.setCellValueFactory(new PropertyValueFactory<>("appointmentID"));
        contactTitleColumn.setCellValueFactory(new PropertyValueFactory<>("title"));
        contactDescriptionColumn.setCellValueFactory(new PropertyValueFactory<>("description"));
        contactStartColumn.setCellValueFactory(new PropertyValueFactory<>("localStartDate"));
        contactEndColumn.setCellValueFactory(new PropertyValueFactory<>("localEndDate"));
        contactCustomerIdColumn.setCellValueFactory(new PropertyValueFactory<>("customerID"));

        checkForUpcomingAppointments();
        showAll();

        for (Contact c : ContactList.getAllContacts())
            contactCombo.getItems().add(c.getName());
    }

    /**
     * on Action method to update the table
     */
    @FXML
    private void filterContactTable() {
        contactTable.setItems(AppointmentList.getContactSchedule(contactCombo.getValue()));
    }


    //region ************************ Appointments ************************

    /**
     * deletes appointment
     */
    @FXML
    private void delApp() {
        Appointment a = (Appointment) appointmentTable.getSelectionModel().getSelectedItem();
        if (a != null && a.deleteFromDatabase())
            showMessage("Successfully deleted " + a.getType() + " appointment with ID " + a.getAppointmentID());
        else
            showError("Unable to delete appointment!");

        appointmentTable.getItems().clear();

        if (monthRadio.isSelected())
            appointmentTable.setItems(AppointmentList.getMonthlyAppointments());
        else if (weekRadio.isSelected())
            appointmentTable.setItems(AppointmentList.getWeeklyAppointments());
        else
            appointmentTable.setItems(AppointmentList.getAllAppointments());
    }

    /**
     * edits appointment
     */
    @FXML
    void editApp() {
        Appointment a = (Appointment) appointmentTable.getSelectionModel().getSelectedItem();

        if (a != null) {
            try {
                Stage stage = (Stage) appEditButton.getScene().getWindow();
                FXMLLoader loader = new FXMLLoader(getClass().getResource("../view/AppointmentView.fxml"));
                Parent root = loader.load();

                Scene scene = new Scene(root);
                stage.setTitle("Edit Appointment");
                stage.setScene(scene);
                stage.show();

                AppointmentController ac = loader.getController();

                ac.showAppointment(a.getAppointmentID());
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            showError("Please select an appointment to edit!");
        }
    }

    /**
     * creates new appointment
     */
    @FXML
    void newApp() {
        try {
            Stage stage = (Stage) appNewButton.getScene().getWindow();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("../view/AppointmentView.fxml"));
            Parent root = loader.load();

            Scene scene = new Scene(root);
            stage.setTitle("New Appointment");
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * on action method to filter by week
     */
    @FXML
    void showWeek() {
        weekRadio.setSelected(true);
        monthRadio.setSelected(false);
        allRadio.setSelected(false);
        appointmentTable.setItems(AppointmentList.getWeeklyAppointments());
    }

    /**
     * on action method to filter by month
     */
    @FXML
    void showMonth() {
        weekRadio.setSelected(false);
        monthRadio.setSelected(true);
        allRadio.setSelected(false);
        appointmentTable.setItems(AppointmentList.getMonthlyAppointments());
    }

    /**
     * on action method to reset to all
     */
    @FXML
    private void showAll() {
        weekRadio.setSelected(false);
        monthRadio.setSelected(false);
        allRadio.setSelected(true);
        appointmentTable.setItems(AppointmentList.getAllAppointments());
    }

    /**
     * checks for upcoming appointments
     */
    private void checkForUpcomingAppointments() {

        Appointment a = AppointmentList.getNextAppointment();

        Alert alert;

        if (a == null) {
            alert = new Alert(Alert.AlertType.INFORMATION, "No appointments are scheduled in the next week", ButtonType.OK);
        } else if (a.getStart().minusSeconds(15 * 60).isBefore(Instant.now()) && a.getStart().isAfter(Instant.now())) {
            String alertMessage = "Appointment " + a.getAppointmentID() + " starts at " + a.getLocalStartDate();
            alert = new Alert(Alert.AlertType.INFORMATION, alertMessage, ButtonType.OK);
        } else {
            alert = new Alert(Alert.AlertType.INFORMATION, "No upcoming appointments in the next 15 minutes", ButtonType.OK);
        }

        alert.showAndWait();
    }

    //endregion ************************ Appointments ************************


    //region ************************ Customers ************************

    /**
     * deletes customer, but checks to make sure there are no existing appointments first
     */
    @FXML
    void delC() {
        Customer c = (Customer) customerTable.getSelectionModel().getSelectedItem();
        if (!c.isSafeToDelete())
            showError("Unable to delete customer! Please cancel all appointments before deleting!");

        else if (c.deleteFromDatabase())
            showMessage("Successfully deleted customer!");

        else
            showError("Unable to delete customer! I am a teapot!");

        customerTable.getItems().clear();
        customerTable.setItems(CustomerList.getAllCustomers());
    }

    /**
     * goes to edit customer screen
     */
    @FXML
    void editC() {
        Customer c = (Customer) customerTable.getSelectionModel().getSelectedItem();

        if (c != null) {
            try {
                Stage stage = (Stage) cEditButton.getScene().getWindow();
                FXMLLoader loader = new FXMLLoader(getClass().getResource("../view/CustomerView.fxml"));
                Parent root = loader.load();

                Scene scene = new Scene(root);
                stage.setTitle("Edit Customer");
                stage.setScene(scene);
                stage.show();

                CustomerController customerController = loader.getController();

                customerController.showCustomer(c.getCustomerID());
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            showError("Please select a customer to edit!");

        }
    }

    /**
     * goes to create customer screen
     */
    @FXML
    private void newC() {
        try {
            Stage stage = (Stage) cNewButton.getScene().getWindow();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("../view/CustomerView.fxml"));
            Parent root = loader.load();

            Scene scene = new Scene(root);
            stage.setTitle("New Customer");
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    //endregion ************************ Customers ************************

    /**
     * @param s small method to display an "error". Takes in a string to display
     */
    private void showError(String s) {
        appMsgBox.setStyle("-fx-text-fill: red");
        appMsgBox.setText(s);
        custMsgBox.setStyle("-fx-text-fill: red");
        custMsgBox.setText(s);
    }

    /**
     * @param s small method to display a message. Takes in a string to display
     */
    private void showMessage(String s) {
        appMsgBox.setStyle("-fx-text-fill: black");
        appMsgBox.setText(s);
        custMsgBox.setStyle("-fx-text-fill: black");
        custMsgBox.setText(s);
    }
}
