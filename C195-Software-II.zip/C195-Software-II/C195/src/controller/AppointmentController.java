package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Rectangle2D;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Screen;
import javafx.stage.Stage;
import object.*;

import java.io.IOException;
import java.net.URL;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.Comparator;
import java.util.ResourceBundle;

public class AppointmentController implements Initializable {

    //region ************************* FXML Variables *************************
    @FXML
    private TextField appIDField;

    @FXML
    private Button cancelButton;

    @FXML
    private ComboBox<String> contactCombo;

    @FXML
    private ComboBox<String> customerCombo;

    @FXML
    private DatePicker datePicker;

    @FXML
    private TextArea descField;

    @FXML
    private TextField locField;

    @FXML
    private Label msgBox;

    @FXML
    private Button saveButton;

    @FXML
    private ComboBox<LocalTime> timeCombo;

    @FXML
    private TextField titleField;

    @FXML
    private TextField typeField;

    //endregion ************************* FXML Variables *************************

    private final ZoneId zoneId = ZoneId.systemDefault();
    private Appointment appointment;

    /**
     * collects the information, validates it, then saves it to the database
     */
    @FXML
    private void onSave() {
        appointment.setAppointmentID(Integer.parseInt(appIDField.getText()));
        appointment.setTitle(titleField.getText());
        if (appointment.getCreateDate() == null) {
            appointment.setCreateDate(Instant.now());
            appointment.setCreatedBy(LoginController.currentUser);
        }
        appointment.setUpdateDate(Instant.now());
        appointment.setUpdatedBy(LoginController.currentUser);
        appointment.setLocation(locField.getText());
        appointment.setType(typeField.getText());
        appointment.setDescription(descField.getText());
        appointment.setCustomerID(CustomerList.lookupCustomer(customerCombo.getValue()).getCustomerID());
        appointment.setUserID(UserList.lookupUser(LoginController.currentUser).getId());
        appointment.setContactID(ContactList.lookupContact(contactCombo.getValue()).getId());

        try {
            ZonedDateTime zonedDateTime = ZonedDateTime.of(datePicker.getValue(), timeCombo.getValue(), zoneId);

            appointment.setStart(zonedDateTime.withZoneSameInstant(ZoneId.of("UTC")).toInstant());
            appointment.setEnd(zonedDateTime.withZoneSameInstant(ZoneId.of("UTC")).plusHours(1).toInstant());


            if (!appointment.validate())
                showError("Unable to convert provided information into valid data!");
            else if (appointment.writeToDatabase())
                toHome();
            else
                showError("Unable to save appointment to database!");
        } catch (Exception e) {
            showError("Unable to convert provided date/time into valid data!");
        }

    }

    /**
     * loads the main screen
     */
    @FXML
    void toHome() {
        try {
            Stage stage = (Stage) cancelButton.getScene().getWindow();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("../view/homeView.fxml"));
            Parent root = loader.load();

            Scene scene = new Scene(root);
            stage.setTitle("Home");
            stage.setScene(scene);
            stage.centerOnScreen();

            Rectangle2D screenBounds = Screen.getPrimary().getVisualBounds();

            stage.setX((screenBounds.getWidth() - stage.getWidth()) / 2);
            stage.setY((screenBounds.getHeight() - stage.getHeight()) / 2);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     *
     * @param id appointment ID to receive
     *
     * shows an appointment that was selected in the previous screen
     */
    public void showAppointment(int id) {
        appointment = AppointmentList.getAppointment(id);

        appIDField.setText(String.valueOf(appointment.getAppointmentID()));
        titleField.setText(appointment.getTitle());
        descField.setText(appointment.getDescription());
        typeField.setText(appointment.getType());
        locField.setText(appointment.getLocation());

        LocalDateTime localDateTime = appointment.getLocalStartDate();

        LocalDate localDate = localDateTime.toLocalDate();
        LocalTime localTime = localDateTime.toLocalTime();

        customerCombo.getSelectionModel().select(CustomerList.lookupCustomer(appointment.getCustomerID()).getName());
        contactCombo.getSelectionModel().select(ContactList.lookupContact(appointment.getContactID()).getName());
        datePicker.setValue(localDate);

        timeCombo.setValue(LocalTime.parse(localTime.format(DateTimeFormatter.ofPattern("HH:mm"))));
    }

    private void populateComboBoxes() {
        for (Customer c : CustomerList.getAllCustomers()) {
            customerCombo.getItems().add(c.getName());
        }

        for (Contact c : ContactList.getAllContacts()) {
            contactCombo.getItems().add(c.getName());
        }

    }

    /**
     * sets up the combo box with the available times. Some calculations need to take place to make sure it all works
     */
    private void setupTimeComboBox() {
        timeCombo.getItems().clear();
        ObservableList<ZonedDateTime> availableTimes = FXCollections.observableArrayList();
        try {
            LocalDate d = datePicker.getValue();

            availableTimes = AppointmentList.getOpenTimes(d.atStartOfDay(ZoneId.systemDefault()));

            if (appointment.getStart() != null)
                availableTimes.add(appointment.getLocalStartDate().atZone(ZoneId.systemDefault()));


            if (availableTimes.isEmpty())
                showError("No available appointments for " + d + "!");
            else
                showMessage(availableTimes.size() + " appointments available");
        } catch (Exception e) {
            showError("Unable to convert provided 'Date' into usable data type");
        }

        Comparator<ZonedDateTime> comparator = Comparator.comparing(ZonedDateTime::getHour);
        availableTimes.sort(comparator);

        for (ZonedDateTime t : availableTimes) {
            LocalTime lt = LocalTime.of(t.withZoneSameInstant(zoneId).getHour(), t.withZoneSameInstant(zoneId).getMinute());
            System.out.println(lt);
            timeCombo.getItems().add(lt);
        }
    }

    /**
     * onAction function to check a date input and take action if successful
     */
    @FXML
    private void onDateAction() {
        msgBox.setText("");

        LocalDate d = datePicker.getValue();
        if (d == null)
            showError("Please select a date!");

        else if (d.isBefore(LocalDate.now(zoneId)))
            showError("You cannot select a date in the past!");

        else
            setupTimeComboBox();
    }

    /**
     *
     * @param url
     * @param resourceBundle
     *
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        appIDField.setText(String.valueOf(AppointmentList.getNextAppointmentID()));
        appointment = new Appointment();
        populateComboBoxes();
    }

    /**
     * @param s small method to display an "error". Takes in a string to display
     */
    private void showError(String s) {
        msgBox.setStyle("-fx-text-fill: red");
        msgBox.setText(s);
    }

    /**
     * @param s small method to display a message. Takes in a string to display
     */
    private void showMessage(String s) {
        msgBox.setStyle("-fx-text-fill: black");
        msgBox.setText(s);
    }
}
