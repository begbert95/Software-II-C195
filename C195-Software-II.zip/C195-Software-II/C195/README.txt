****************************** Appointment Manager ******************************

By Brandon Egbert
begbert95@gmail.com
V1.0
2022-12-27


This program was built for Western Governor's University's C195 course. It allows Appointment and Customer tracking, as
well as 4 reports:
    1. Shows a count of all appointment types
    2. Shows a schedule for each contact
    3. Shows how many customers are in each division
    4. Shows how many appointments each user has scheduled


To run the program, ensure you have the tools at the bottom installed. Open the project directory in your IDE, create a
configuration that points to the main class, and ensure JavaFX is referenced in the project structure




Built using:

IntelliJ Community 2021.1.3
Java SE 17.0.1
JavaFX-SDK-17.0.1
mysql-connector-java-8.1.23